<br>

<h2 align="center" class="text-info">All Lecturers</h2><br>
<table class="table">
	<tr>
	<!-- <th>ID</th> -->
		<th>Name</th>
		<th>User Name</th>
		<th>Email</th>
		<th>Gender</th>
	</tr>

	<?php if (isset($lecturers )) {
		foreach ($lecturers as $lecturer) {   ?>
			<tr>
				<td><?php echo $lecturer['user_name'] ?></td>
				<td><?php echo $lecturer['user_username'] ?></td>
				<td><?php echo $lecturer['user_email'] ?></td>
				<td><?php echo $lecturer['user_gender'] ?></td>
			</tr>
	<?php }
	} ?>

</table>

</div>
