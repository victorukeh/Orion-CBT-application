
<br>
<h2 align="center" class="text-info">All Students</h2><br>
<table class="table">
	<tr>
	<!-- <th>ID</th> -->
		<th>Name</th>
		<th>User Name</th>
		<th>Email</th>
		<th>Gender</th>
	</tr>

	<?php if (isset($students )) {
		foreach ($students  as $student) {   ?>
			<tr>
				<td><?php echo $student['user_name'] ?></td>
				<td><?php echo $student['user_username'] ?></td>
				<td><?php echo $student['user_email'] ?></td>
				<td><?php echo $student['user_gender'] ?></td>
			</tr>
	<?php }
	} ?>

</table>

</div>