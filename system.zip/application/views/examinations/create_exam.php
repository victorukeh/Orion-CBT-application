<div class="page-content">
	<!-- /.ace-settings-container -->

	<div class="page-header">
		<h1><?= $title; ?></h1>
	</div><!-- /.page-header -->
	<?php echo validation_errors(); ?>


	<div class="col-xs-12">

		<?php if (isset($error)) { ?>
			<div class="alert alert-danger"><?php echo $error; ?></div>
		<?php } ?>
		<?php if (isset($success)) { ?>
			<div class="alert alert-success"><?php echo $success; ?></div>
		<?php } ?>

		<div class="col-xs-12">

			<div style="align-self:center" class="form-group">

				<div class="row">
					<div style="display:flex; align-items:center" class="col-md-4 col-md-offst-4">
						<!-- <form class="myForm text-center" action="php echo base_url();?>examinations/create_exam" method="post"> -->
						<?php echo form_open_multipart('examinations/create_exam/'.$udata['user_username'].'/'.$udata['user_id']); ?>
						<div class='form_group'>
							<label>Course Code</label>
							<input type="text" id="test_id" class="chosen-select form-control" name="course" required />
						</div>
						<div class='form_group'>
							<label>Assessment Name</label>
							<input type="text" id="test_id" class="chosen-select form-control" name="test_name" required />
						</div>
						<div class="form-group">
							<label>Instruction</label>
							<textarea name="instruction" class="chosen-select form-control" rows="3" cols="40"></textarea><br>
						</div>
						<div class='form_group'>
							<label>Date</label>
							<input type="date" class="form-control" name="date" placeholder="date of creation" required />
						</div>
						<div class='form_group'>
							<label>Duration</label>
							<input type="number" class="chosen-select form-control" id="time_id" name="duration" required /><br>
						</div>
						<div class='form_group'>
							<label>Exam Password</label>
							<input type="password" id="test_id" class="chosen-select form-control" name="password" required />
						</div>
						<br>
						<input type="submit" class="btn btn-success" name="submit_form" value="Submit"> &nbsp;
						<input type="reset" class="btn btn-danger" name="reset_form" value="Reset">
						</form>
					</div>
				</div>
			</div>

		</div><!-- /.row -->
	</div><!-- /.page-content -->
</div>