<h2><?= $title; ?></h2>

<?php echo validation_errors(); ?>


<div class="col-xs-12">

	<div class="form-group">

		<div class="row">
			<div class="col-md-4 col-md-offst-4">
				<?php echo form_open('examinations/edit_exam'); ?>
				<div class='form_group'>
					<label>Course Code</label>
					<input type="text" id="test_id" class="chosen-select form-control" name="course" required />
				</div>
				<div class="form-group">
					<label>Instruction</label>
					<textarea name="instruction" class="chosen-select form-control" rows="3" cols="40"></textarea><br>
				</div>
				<div class='form_group'>
					<label>Duration</label>
					<input type="number" class="chosen-select form-control" id="time_id" name="duration" required /><br>
				</div>
				<div class='form_group'>
					<label>Exam Password</label>
					<input type="password" id="test_id" class="chosen-select form-control" name="password" required />
				</div>
				<input type="submit" class="btn btn-success" name="submit_form" value="Submit"> &nbsp;
				<input type="reset" class="btn btn-danger" name="reset_form" value="Reset">
				</form>
				</div>
				</div>
			</div>

		</div><!-- /.row -->
	</div><!-- /.page-content -->
</div>

				<!-- <form class="myForm text-center" action="php echo base_url();?>examinations/create_exam" method="post"> -->
				<!-- <?php echo form_open_multipart('examinations/create_exam'); ?> -->