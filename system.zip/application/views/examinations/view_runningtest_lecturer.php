<div class="page-header">
	<h1>
		All Assessments
	</h1>
</div><!-- /.page-header -->

<div>
	<div class="form-group">

		<form method="post">
			<input type="text" name="search" class="chosen-select form-control" placeholder="write your test name"><br>
			<input type="submit" value="search" class="btn btn-success" name="srcbutton">
		</form>

	</div><br> 

	<?php foreach ($examlist as $exam) { ?>

		<div class="media search-media">
			<div class="media-left">
				<a href="#">
					<img class="media-object" data-src="holder.js/72x72" />
				</a>
			</div>

			<div style="background:cornsilk; border-radius:10px; max-width:80%;" class="media-body">

				<div style="padding-left:10px;">
					<h4 class="media-heading">
						<a href="#" class="blue"><?php echo $exam['course']; ?> <?php echo $exam['test_name']; ?></a>
					</h4>
				</div>
				<p style="padding-left:10px;"> <?php echo $exam['instruction']; ?> </p>

				<div style="padding-left:300px;"class="search-actions text-center">
					<!-- <span class="text-info"><?php echo $no ?></span> -->
					<span style="color:darkcyan" class="blue bolder bigger-150"><?php echo $exam['duration']; ?> Minutes</span><br>
					
					<form>
					
					<button class="btn btn-warning" style="height:38px;"><a style="color:#fff; padding-top:1px"class="btn btn-default pull-left" href="<?php echo base_url(); ?>examinations/edit_exam/<?php echo $exam['exam_id']; ?>">Edit</a></button>
					<button class="btn btn-primary" style="height:38px;"><a style="color:#fff; padding-top:1px"class="btn btn-default pull-left" href="<?php echo base_url(); ?>examinations/add_question/<?php echo $exam['exam_id']; ?>">Add Question</a></button>

						
						<?php echo form_open('/examinaions/delete_exam/' . $exam['exam_id']); ?>
						<input type="submit" value="Delete" class="btn btn-danger">
					</form>
					<br>

				</div>
			</div>
		</div>
	<?php } ?>

</div>




</div>
