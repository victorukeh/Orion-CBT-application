
<div style="padding-top:30px"class="page-header">
	<h2>
		All Assessments
	</h2>
</div><!-- /.page-header -->

<div>
	<div class="form-group">

		<form method="post">
			<input type="text" name="search" class="chosen-select form-control" placeholder="write your test name"><br>
			<input type="submit" value="search" class="btn btn-success" name="srcbutton">
		</form>

	</div><br>

	<?php foreach ($examlist as $exam) { ?>

		<div class="media search-media">
			<div  class="media-left">
				<a href="#">
					<img class="media-object" data-src="holder.js/72x72" />
				</a>
			</div>

			<div class="media-body">

				<div>
					<h4 class="media-heading">
						<a href="#" class="blue"><?php echo $exam['course']; ?> <?php echo $exam['test_name']; ?></a>
					</h4>
				</div>
				<p> <?php echo $exam['instruction']; ?> </p>

				<div class="search-actions text-center">
					<span class="text-info"></span>

					<span class="blue bolder bigger-150"><?php echo $exam['duration']; ?> Minutes</span><br>

					
					<a class="search-btn-action btn btn-sm btn-block btn-info" href="<?php echo base_url(); ?>examinations/questions/<?php echo $all['user_id']; ?>/<?php echo $exam['exam_id']; ?>/<?php echo $users['user_id']; ?> ?>">Take it!</a>
				</div>
			</div>
		</div>
	<?php } ?>

</div>




</div>
