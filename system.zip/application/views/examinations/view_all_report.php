<div class="main-content">
	<div class="main-content-inner">

<br>
		<div class="page-content">
			<!-- /.ace-settings-container -->

			<div class="page-header">
				<h2>
					Students Exam History Across All Assessments

				</h2>
			</div><!-- /.page-header -->


			<div class="col-xs-12">

				<?php
				if (isset($message)) {
					echo "<p class='alert alert-danger'>" . $message . "</p>";
				}
				?>

				<div class="col-xs-12">

					<div class="form-group">

						<form method="post" action="<?php echo base_url(); ?>examinations/searchResult1">

							<label> Search Score By User Name </label>
							<input class="chosen-select form-control" type="text" id="user_id" name="users_name" required /><br>

							<input type="submit" class="btn btn-success" name="submit_form" value="Search"> &nbsp;

							<input type="reset" class="btn btn-danger" value="Reset">

						</form><br>

						<table class="table">

							<?php if (isset($all_mark)) {    ?>
								<tr>
									<th>User Name</th>
									<th>Score</th>
									<th>Date</th>
									<th>Time</th>
									<th>Test Name</th>
								</tr>
								<?php foreach ($all_mark as $mark) {   ?>
									<tr>
									<td><?php echo $marks['user_username'] ?></td>
										<td><?php echo $marks['score'] ?></td>
										<td><?php echo $mark['date'] ?></td>
										<td><?php echo $mark['time'] ?></td>
										<td><?php echo $mark['test_name'] ?></td>
									</tr>
							<?php }
							} ?>

						</table>

						<h2 align="center" class="text-info">All Students Score History</h2><br>
						<table class="table">
							<tr>
								<th>User Name</th>
								<th>Score</th>
								<th>Date</th>
								<th>Time</th>
								<th>Test Name</th>
							</tr>

							<?php if (isset($all_marks)) {
								foreach ($all_marks as $marks) {   ?>
									<tr>
										<td><?php echo $marks['user_username'] ?></td>
										<td><?php echo $marks['score'] ?></td>
										<td><?php echo $marks['date'] ?></td>
										<td><?php echo $marks['time'] ?></td>
										<td><?php echo $marks['test_name'] ?></td>
									</tr>
							<?php }
							} ?>

						</table>

					</div>

				</div>
				<!-- /.row -->
			</div><!-- /.page-content -->
		</div>
	</div><!-- /.main-content -->