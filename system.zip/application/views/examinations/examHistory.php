<div class="page-header">
	<h1>
		Assessment History
	</h1>
</div><!-- /.page-header -->
<div>

	<table class="table">
		<tr>
			<th>Test Name</th>
			<th>Mark</th>
			<th>Time</th>
			<th>Date</th>

		</tr>
		<?php foreach ($history as $exam) { ?>
			<tr>
				<td><?php echo $exam['test_name']; ?></td>
				<td><?php echo $exam['score']; ?></td>
				<td><?php echo $exam['time']; ?></td>
				<td><?php echo $exam['date']; ?></td>
			</tr>
		<?php } ?>
	</table>

</div>