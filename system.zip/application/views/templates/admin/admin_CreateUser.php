<!DOCTYPE html>
<html lang="en">

<head>
	<title>Orion Admin Dashboard</title>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css" integrity="sha512-1PKOgIY59xJ8Co8+NE6FZ+LOAZKjy+KY8iq0G4B3CyeY6wYHN3yt9PW0XpSriVlkMXe40PTKnXrLnZ9+fkDaog==" crossorigin="anonymous" />
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/flatly.css">
	<script src="<?php echo base_url(); ?>assets/js/function.js"></script>
	<script src="http://cdn.ckeditor.com/4.5.11/standard/ckeditor.js"></script>

</head>

<body>
	<div class="container">
		<div class="navigation">
			<ul>
				<li>
					<a href="#">
						<span class="icon"><i class="fab fa-confluence" aria-hidden="true"></i></span>
						<span>
							<h2 class="title">Orion</h2>
						</span>
					</a>
				</li>
				<li class="list">
					<b></b>
					<b></b>
					<a href="<?php echo base_url(); ?>user/admin/<?php echo $udata['user_id'] ?>">
						<span class="icon"><i class="fas fa-desktop"></i></span>
						<span class="title">Admin Dashboard</span>
					</a>
				</li>
				<li class="list active">
					<b></b>
					<b></b>
					<a href="<?php echo base_url(); ?>user/create_user/<?php echo $udata['user_id'] ?>">
						<span class="icon"><i class="fas fa-user-circle"></i></span>
						<span class="title">Create User</span>
					</a>
				</li>
				<li class="list">
					<b></b>
					<b></b>
					<a href="<?php echo base_url(); ?>user/get_all_lecturers/<?php echo $udata['user_id'] ?>">
						<span class="icon"><i class="fa fa-address-card" aria-hidden="true"></i></span>
						<span class="title"> View Lecturers</span>
					</a>
				</li>
				<li class="list">
					<b></b>
					<b></b>
					<a href="<?php echo base_url(); ?>user/get_all_students/<?php echo $udata['user_id'] ?>">
						<span class="icon"><i class="fas fa-book-reader"></i></span>
						<span class="title"> View Students</span>
					</a>
				</li>
				<li class="list">
					<b></b>
					<b></b>
					<a href="#">
						<span class="icon"><i class="fa fa-book" aria-hidden="true"></i></span>
						<span class="title">Manage Courses</span>
					</a>
				</li>
				<li class="list">
					<b></b>
					<b></b>
					<a href="<?php echo base_url(); ?>examinations/adminviewResult/<?php echo $udata['user_username'] ?>">
						<span class="icon"><i class="fa fa-graduation-cap" aria-hidden="true"></i></span>
						<span class="title">View all students reports</span>
					</a>
				</li>
				<li class="list">
					<b></b>
					<b></b>
					<a href="#">
						<span class="icon"><i class="fas fa-lock"></i></span>
						<span class="title">Change Password</span>
					</a>
				</li>


				<li class="list">
					<b></b>
					<b></b>
					<a href="<?php echo base_url(); ?>user/logout">
						<span class="icon"><i class="fas fa-power-off"></i></span>
						<span class="title">Sign Out</span>
					</a>
				</li>


			</ul>
		</div>


		<div class="main">
			<div class="topbar">
				<div class="toggle">
					<i class="fa fa-bars  open"></i>
					<i class="fa fa-window-close close"></i>
				</div>
				<div class="search" style="color:black">
					<label>
						<span> Welcome <?php echo $udata['user_name'] ?></span>
					</label>
				</div>
			</div>

			<!-- </div>
	</div> -->
	
	  <!-- Flash messages -->
      <?php if($this->session->flashdata('user_registered')): ?>
        <?php echo '<p class="alert alert-success">'.$this->session->flashdata('user_registered').'</p>'; ?>
      <?php endif; ?>
	  <?php unset($_SESSION['user_registered']);?>
     
