


<div class="page-content">
	<!-- /.ace-settings-container -->

	<div class="page-header">
		<h1>
			Result
		</h1>
	</div><!-- /.page-header -->

	<div>

		<h2 class="control-label bolder blue" style="text-align:center;"><?php echo "Your Score : " . (int)$score ?></h2>

	</div>
	<!-- /.row -->
</div><!-- /.page-content -->
</div>
</div><!-- /.main-content -->