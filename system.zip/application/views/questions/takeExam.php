<div id="container">
	<h1>Take Exam</h1>
	<form method="" action="<?php echo base_url(); ?> examinations/takeExam">
		<input type="submit" value="Start">
	</form>
</div>
