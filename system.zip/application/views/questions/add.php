<br>
<h2><?= $title; ?></h2>

<?php echo validation_errors(); ?>

<?php echo form_open_multipart('examinations/add_question/' . $exam['exam_id']); ?>
<div class="col-xs-12">

	<div class="form-group">

		<div class="row">
			<div class="col-md-4 col-md-offst-4">
				
				<div class="form-group">
					<label>Question</label>
					<textarea id="editor1" class="form-control" name="question" placeholder="Enter Question"></textarea>
				</div>
				<br>
				<div class="form-group">
					<label>Option A</label>
					<input type="text" class="form-control" name="option_a" placeholder="Enter the first option">
				</div>
				<br>
				<div class="form-group">
					<label>Option B</label>
					<input type="text" class="form-control" name="option_b" placeholder="Enter the second option">
				</div>
				<br>
				<div class="form-group">
					<label>Option C</label>
					<input type="text" class="form-control" name="option_c" placeholder="Enter the third option">
				</div>
				<br>
				<div class="form-group">
					<label>Option D</label>
					<input type="text" class="form-control" name="option_d" placeholder="Enter the fourth option">
				</div>
				<br>
				<div class="form-group">
					<label>Answer</label>
					<input type="text" class="form-control" name="answer" placeholder="Enter the correct Answer">
				</div>
				<br>
				<div class="search-actions text-center">
					<button type="submit" class="btn btn-warning" style="height:38px; width:100%;">Add Question</button>
				</div>
				<br>
			</div>
		</div>
	</div>

</div>
