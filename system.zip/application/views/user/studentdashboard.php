<div style="padding-top: 130px" class="main-content">
	<div class="main-content-inner">
		<div class="main-content">
			<div class="main-content-inner">
				<!-- <div align="center" class="page-header">
					<h3>
						Dashboard
					</h3>
				</div> -->
				<!-- /.page-header -->
				<div >
					<p align="center"><b class="text-danger">Name : </b><?php echo $udata['user_name'] ?><br><br>
					<b class="text-danger">Matric Number : </b><?php echo $udata['user_username'] ?><br><br>
					<b class="text-danger">User Email : </b><?php echo $udata['user_email'] ?><br><br>
						<b class="text-danger">Gender : </b><?php echo $udata['user_gender'] ?><br><br>
						<b class="text-danger">Total Given Exams : </b><?php echo $no ?>
					</p>


				</div>
			</div>
			<!-- /.row -->
		</div><!-- /.page-content -->
	</div>
</div><!-- /.main-content -->
