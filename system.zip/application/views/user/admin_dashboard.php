<div class="main-content">
	<div class="main-content-inner">


		<div class="page-content">
			<!-- /.ace-settings-container -->

			<div class="page-header">
				<h1>
					Dashboard
				</h1>
			</div><!-- /.page-header -->
			<div>
				<p align="center"><b class="text-danger">Most Active user : </b><?php echo $mau; ?></br></br>
					<b class="text-danger">Most Given Exam : </b><?php echo $mge; ?></br></br>
					<b class="text-danger">Total Number of Users : </b><?php echo $total; ?></br></br>
					<b class="text-danger">Total Number of Students : </b><?php echo $total1; ?></br></br>
					<b class="text-danger">Total Number of Lecturers : </b><?php echo $total2; ?></br></br>
					<b class="text-danger">Total Number of Examinations : </b><?php echo $total3; ?></br></br>
				</p>
			</div>
			<!-- /.row -->
		</div><!-- /.page-content -->
	</div>
</div><!-- /.main-content -->