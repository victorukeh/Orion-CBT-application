<div class="main-content">
	<div class="main-content-inner">
		<div class="main-content">
			<div class="main-content-inner">
				<!-- <div class="page-header">
					<h1>
						Dashboard
					</h1>
				</div>/.page-header -->
				<div style="padding-top:60px">
					<p align="center"><b class="text-danger">Name : </b><?php echo $udata['user_name'] ?><br><br>
					<b class="text-danger">Lecturer ID : </b><?php echo $udata['user_username'] ?><br><br>
					<b class="text-danger">User Email : </b><?php echo $udata['user_email'] ?><br><br>
						<b class="text-danger">Gender : </b><?php echo $udata['user_gender'] ?><br><br>
						<b class="text-danger">Total Created Exams : </b><?php echo $no ?>
					</p>


				</div>
			</div>
			<!-- /.row -->
		</div><!-- /.page-content -->
	</div>
</div><!-- /.main-content -->
