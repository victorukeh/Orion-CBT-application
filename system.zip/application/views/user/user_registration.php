<?php echo validation_errors(); ?>

<?php echo form_open('user/create_user/'. $udata['user_id'] );?>
	<div class="row"
	
	>
	<!-- , paste -->
		<div class="col-md-4 col-md-offset-4">
			<h2 class="text-center">User Registeration</h2>
			<div class="form-group">
				<label>Name</label>
				<input type="text" class="form-control" name="user_name" >
			</div>
			<div class="form-group">
				<label>Username</label>
				<input type="text" class="form-control" name="user_username">
			</div>
			<div class="form-group">
				<label>Email</label>
				<input type="email" class="form-control" name="user_email">
			</div>
			<div class="form-group">
				<label>Gender</label>
				<input type="text" class="form-control" name="user_gender" >
			</div>
			<div class="form-group">
				<label>Password</label>
				<input type="password" class="form-control" name="user_password" >
			</div>
			<div class="form-group">
				<label>Role</label>
				<input type="text" class="form-control" name="user_type" >
			</div>
			<br>
			<button style="height:38px; width:100%;" type="submit" class="btn btn-primary btn-block">Register</button>
		</div>
	</div>
<?php echo form_close(); ?>
