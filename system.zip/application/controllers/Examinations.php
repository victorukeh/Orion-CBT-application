<?php

class Examinations extends CI_Controller
{

	public function index()
	{
		//Check Login
		if (!$this->session->userdata('logged_in')) {
			redirect('users/login');
		}

		$this->load->model('Examination_model', 'examination_model');
		$data['title'] = 'Examinations';
		$data['examinations'] = $this->examination_model->get_examinations();

		$this->load->view('templates/header');
		$this->load->view('examinations/index', $data);
		$this->load->view('templates/footer');
	}

	public function create_exam($name = null, $id = 0)
	{
		// Check Login
		if (!$this->session->userdata('logged_in')) {
			redirect('user/login');
		}

		$this->load->model('User_model', 'user_model');
		$this->load->model('Examination_model', 'examination_model');
		$asdata = array('udata' => $this->user_model->getById($id));
		$data['udata'] = $this->user_model->getById($id);

		// print_r($data);

		$data['title'] = 'Create Exam';

		$this->form_validation->set_rules('course', 'Course', 'required|min_length[4]|is_unique[examinations.course]');
		$this->form_validation->set_rules('test_name', 'TestName', 'required');
		$this->form_validation->set_rules('date', 'Date', 'required');
		$this->form_validation->set_rules('duration', 'Duration', 'required');
		$this->form_validation->set_rules('instruction', 'Instruction', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');
		if ($this->form_validation->run() == FALSE) {
			$this->load->view('templates/lecturer_createExam_navbar', $asdata);
			$this->load->view('examinations/create_exam', $data);
			$this->load->view('templates/user_navbars_footer');
		} else {
			$this->examination_model->create_exam($id);
			$this->session->set_flashdata('exam_created', 'Exam has been successfully registerd');
			redirect('examinations/viewExamsCreated/' . $name);
		}
	}

	public function edit_exam($id = 0)
	{
		if (!$this->session->userdata('logged_in')) {
			redirect('user/login');
		}

		// else if ($id == 0 || $id != $this->session->userdata('usernames')) {
		// 	redirect('user/login');
		// }
		$data['title'] = 'Edit Exam';
		$this->load->model('User_model', 'user_model');
		$this->load->model('Examination_model', 'examination_model');
		$data['post'] = $this->examination_model->getexambyId($id);
		$sname = $this->examination_model->getexambyId($id);
		$sdata = array('udata' => $this->examination_model->getbyId($sname['user_id']));
		$this->form_validation->set_rules('course', 'Course', 'required|min_length[4]|is_unique[examinations.course]');
		// $this->form_validation->set_rules('date', 'Date', 'required');
		$this->form_validation->set_rules('duration', 'Duration', 'required');
		$this->form_validation->set_rules('instruction', 'Instruction', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');
		if ($this->form_validation->run() == FALSE) {
			$this->load->view('templates/lecturer_createExam_navbar', $sdata);
			$this->load->view('examinations/edit_exam', $data);
			$this->load->view('templates/user_navbars_footer');
		} else {
			$this->load->model('Examination_model', 'examination_model');

			$this->examination_model->update(
				['examid' => $id],
				[
					'instruction' => $this->input->post('instruction'),
					'course' => $this->input->post('course'),
					'duration' => $this->input->post('duration'),
					'password' => $this->input->post('password')

				]


			);
		}
	}

	public function delete_exam($exam_id)
	{
		if (!$this->session->userdata('logged_in')) {
			redirect('user/login');
		}
		$data = array();
		// $name = $this->usermodel->($exam_id);

		$this->load->model('User_model', 'user_model');
		$data = $this->user_model->getByExamID($exam_id);
		$this->load->model('Examination_model', 'examination_model');
		$this->load->model('Question_model', 'question_model');

		$data = $this->examination_model->delete(['exam_id' => $exam_id]);
		$query = $this->question_model->delete(['question_id' => $exam_id]);

		if ($query && $data) {
			redirect('examinations/viewExamsCreated' . $exam_id);
		}
	}


	public function examHistory($name = null)
	{
		if (!$this->session->userdata('logged_in')) {
			redirect('user/login');
		} else if ($name == null || $name != $this->session->userdata('usernames')) {
			echo "No Data Found";
			return;
		}

		$this->load->model('User_model', 'user_model');
		$data['history'] = $this->user_model->getHistoryByName($name);
		$data['all'] = $this->user_model->getAll2($name);
		$sdata = array('udata' => $this->user_model->getAll2($name));
		$this->load->view('templates/user_examsHistory_navbar', $sdata);
		$this->load->view('examinations/examHistory', $data);
		$this->load->view('templates/user_navbars_footer');
	}

	// QUESTIONS //

	public function questions($id, $exam_id)
	{
		if (!$this->session->userdata('logged_in')) {
			redirect('user/login');
		}

		if ($id == 0 ||  $id != $this->session->userdata('userids') || $exam_id == null) {
			// echo "No Data Found";
			// return;
			redirect('user/login');
		}
		$data = array();
		$this->load->model('Examination_model', 'examination_model');
		$this->load->model('Question_model', 'question_model');
		$this->load->model('User_model', 'user_model');
		$data['users'] = $this->user_model->getById($id);
		$data['title'] = $this->examination_model->get_examination($exam_id)->course;
		$data['exam'] = $this->examination_model->get_examination($exam_id);
		$data['questions'] = $this->question_model->get_questions_by_examination($exam_id);
		$data['all_test'] = $this->examination_model->select_examination_details_by_test_name($exam_id);

		$this->load->view('templates/user_questions_header', $data);
		$this->load->view('questions/index', $data);
		$this->load->view('templates/user_footer');
	}

	public function add_question($id = 0)
	{
		if (!$this->session->userdata('logged_in')) {
			redirect('user/login');
		}

		$this->load->model('Examination_model', 'examination_model');
		$data['title'] = 'Add Question';
		$this->load->model('User_model', 'user_model');
		$sname = $this->examination_model->getexambyId($id);
		$asdata = array('udata' => $this->examination_model->getById($sname['user_id']));
		$name = $this->user_model->getById5($sname['user_id'])->user_username;
		// print_r($name);
		$data['examinations'] = $this->examination_model->get_examinations();
		$data['exam'] = $this->examination_model->get_exam($id);
		$testname = $this->examination_model->get_exam2($id)->test_name;
		// print_r($testname);
		$superdata = array(
			'examination_id' => $id,
			'test_name' => $testname,
			'question' => $this->input->post('question'),
			'option_a' => $this->input->post('option_a'),
			'option_b' => $this->input->post('option_b'),
			'option_c' => $this->input->post('option_c'),
			'option_d' => $this->input->post('option_d'),
			'answer' => $this->input->post('answer'),
		);
		// print_r($superdata['test_name']);
		// print_r($data['exam']);
		$this->form_validation->set_rules('question', 'Question', 'required|min_length[4]');
		$this->form_validation->set_rules('option_a', 'Option A', 'required');
		$this->form_validation->set_rules('answer', 'Answer', 'required');

		if ($this->form_validation->run() == FALSE) {
			$this->load->view('templates/lecturer_runningtest_navbar', $asdata);
			$this->load->view('questions/add', $data);
			$this->load->view('templates/user_navbars_footer');
		} else {
			
			$superdata = array(
				'examination_id' => $id,
				'test_name' => $testname,
				'question' => $this->input->post('question'),
				'option_a' => $this->input->post('option_a'),
				'option_b' => $this->input->post('option_b'),
				'option_c' => $this->input->post('option_c'),
				'option_d' => $this->input->post('option_d'),
				'answer' => $this->input->post('answer'),
			);
			$this->load->model('Examination_model', 'examination_model');
			$this->load->model('Question_model', 'question_model');

			$this->question_model->add_a_question($superdata);
			redirect('examinations/viewExamsCreated/'. $name);

			$this->session->set_flashdata('question_created', 'Your Question has been created');
		}
	}

	public function edit_question($question_id, $exam_id)
	{
		if (!$this->session->userdata('logged_in')) {
			redirect('user/login');
		}

		$this->form_validation->set_rules('question', 'Question', 'required|min_length[4]');
		$this->form_validation->set_rules('option_a', 'Option A', 'required');
		$this->form_validation->set_rules('option_b', 'Option B', 'required');
		$this->form_validation->set_rules('option_c', 'Option C', 'required');
		$this->form_validation->set_rules('answer', 'Answer', 'required');


		if ($this->form_validation->run() == FALSE) {
			$this->load->view('templates/header');
			$this->load->view('questions/edit');
			$this->load->view('templates/footer');
		} else {
			$this->load->model('Question_model', 'question_model');
			$this->load->model('Examination_model', 'examination_model');

			$this->question_model->update(
				['question_id' => $question_id],
				[
					'Examination_id' => $exam_id,
					'question' => $this->input->post('obj_question'),
					'option_A' => $this->input->post('obj_a'),
					'option_B' => $this->input->post('obj_b'),
					'option_C' => $this->input->post('obj_c'),
					'answer' => $this->input->post('answer'),
				]
			);
		}
	}


	public function delete_question($question_id)
	{
		$this->load->model('Question_model', 'question_model');
		$this->question_model->delete_post($question_id);
	}



	public function resultDisplay($name, $id = 0)
	{
		if (!$this->session->userdata('logged_in')) {
			redirect('user/login');
		} else if ($id == 0 || $id != $this->session->userdata('userids') || $name == null) {
			// echo "No Data Found";
			// return;
			redirect('user/login');
		}

		$score = 0;
		date_default_timezone_set("Africa/Lagos");
		// $asdata = array();
		$sdata['date'] = date("d/m/Y");
		$sdata['time'] = date("h:i:sa");
		$sdata['intTime'] = date("his");
		$this->load->model('User_model', 'user_model');
		$sdata['test_name'] = $name;
		$data = $this->user_model->getById($id);
		$sdata['user_username'] = $data['user_username'];
		$this->load->model('User_model', 'user_model');
		$asdata = array('udata' => $this->user_model->getById($id));
		$this->load->model('Question_model', 'question_model');
		$datas = $this->question_model->select_question_details_by_test_name($this->input->post('testName'));

		foreach ($datas as $test) {

			if ($this->input->post('form_option' . $test['question_id']) == $test['answer']) {
				$score = $score + 1;
			} else {
				$score = $score + 0;
			}
			if ($id == 0 || $id != $this->session->userdata('userids') || $name == null) {
				echo "No Data Found";
				return;
			}
		}
		$sdata['score'] = $score;
		$this->load->model('Question_model', 'question_model');
		$this->question_model->insert_score($sdata);
		$this->load->view('templates/user_result_navbar', $asdata,);
		$this->load->view('questions/result_display', $sdata);
		$this->load->view('templates/user_navbars_footer');
	}

	public function viewExams($name = null)
	{
		if (!$this->session->userdata('logged_in')) {
			redirect('user/login');
		} else if ($name == null || $name != $this->session->userdata('usernames')) {
			// echo "No Data Found";
			// return;
			redirect('user/login');
		}

		// Search Bar is not working well
		if (!$this->input->get_post("srcbutton")) {
			$this->load->model('Examination_model', 'examination_model');
			// $this->load->model('User_model', 'usermodel');
			$data['users'] = $this->examination_model->getAll($name);
			$data['examlist'] = $this->examination_model->getallexam();
			$data['all'] = $this->examination_model->getAll($name);
			// $this->load->model('User_model', 'user_model');
			$sdata = array('udata' => $this->examination_model->getAll($name));
			$this->load->view('templates/user_runningtest_navbar', $sdata);
			$this->load->view('examinations/view_runningtest', $data);
			$this->load->view('templates/user_navbars_footer');
		}

		// $this->load->model('Examination_model', 'examination_model');
		// $data['examlist'] = $this->examination_model->getsrcexam($this->input->get_post("search"));
		// $data['all'] = $this->examination_model->getAll($name);
		// $sdata = array('udata' => $this->examination_model->getAll($name));
		// $this->load->view('templates/user_runningtest_navbar', $sdata);
		// $this->load->view('examinations/view_runningtest', $data);
		// $this->load->view('templates/user_navbars_footer');
	}

	public function viewExamsCreated($name = null)
	{
		if (!$this->session->userdata('logged_in')) {
			redirect('user/login');
		} else if ($name == null || $name != $this->session->userdata('usernames')) {
			redirect('user/login');
		}

		$this->load->model('Examination_model', 'examination_model');
		$this->load->model('User_model', 'user_model');
		$sname = $this->user_model->getByName($name);
		// print_r($sname );
		$data['examlist'] = $this->user_model->get_exams($sname['user_id']);
		$data['all'] = $this->examination_model->getAll($name);
		$sdata = array('udata' => $this->examination_model->getAll($name) 
		// ,'no' => sizeof($this->user_model->getexamnum($questions['examination_id']))
	);
		$this->load->view('templates/lecturer_runningtest_navbar', $sdata); 
		$this->load->view('examinations/view_runningtest_lecturer', $data);
		$this->load->view('templates/user_navbars_footer');


		if ($this->input->get_post("srcbutton")) {
			// Search Bar is not working well
			$this->load->model('Examination_model', 'examination_model');
			$this->load->model('User_model', 'user_model');
			$sname = $this->user_model->getByName($name);
			$data['examlist'] = $this->examination_model->getsrcexam($this->input->get_post("search"));
			// print_r($data['examlist'] );
			$examinations = $this->user_model->get_exams($sname['user_id']);
		$questions = $this->user_model->get_questions($examinations['exam_id']);
		$data['all'] = $this->examination_model->getAll($name);
		$sdata = array('udata' => $this->examination_model->getAll($name), 'no' => sizeof($this->usermodel->getexamnum($questions['exam_id'])));
			$this->load->view('templates/lecturer_runningtest_navbar', $sdata);
			$this->load->view('examinations/view_runningtest_lecturer', $data);
			$this->load->view('templates/user_navbars_footer');
		}
	}

	public function viewResult($name)
	{
		$this->load->model('User_model', 'usermodel');
		$semi = $this->usermodel->getTestNameByExam($name);
		$demi = $this->usermodel->getExamByUserID($semi['user_id']);
		$this->load->model('Examination_model', 'examination_model');
		$data['all_marks'] = $this->examination_model->getMarksByExam($demi['test_name']);
		$this->load->library('parser');
		$adata = array('udata' => $this->examination_model->getAll($name));
		$this->load->view('templates/lecturer_view_navbar', $adata);
		$this->parser->parse('examinations/view_reports', $data);
		$this->load->view('templates/user_navbars_footer');
	}

	public function adminviewResult($name)
    {
			$this->load->model('Examination_model', 'examination_model');
		$adata = array('udata' => $this->examination_model->getAll($name));
        $data['all_marks'] = $this->examination_model->allUserMarks();
        $this->load->library('parser');
		$this->load->view('templates/admin/admin_viewResult', $adata);
		$this->parser->parse('examinations/view_all_report', $data);
		$this->load->view('templates/user_navbars_footer');
    }

	public function searchResult()
	{
		$all = "";
		$name = $this->input->post('users_name');
		$this->load->model('Examination_model', 'examination_model');
		$data['all_mark'] = $this->examination_model->searchUserMarks($name);
		$data['all_marks'] = $this->examination_model->allUserMarks();
		$userName = $this->examination_model->userName();

		foreach ($userName as $users) {
			$all .= $users['user_username'];
		}

		if ($this->input->post('submit_form')) {
			if (strpos($all, $name) !== false) {
				$this->load->view('examinations/view_reports', $data);
			} else {
				$data['message'] = 'No Data Found';
				$this->load->view('examinations/view_reports', $data);
			}
		} else {
			// redirect('http://localhost/MidAtp/admin/viewResult', 'refresh');
			//     $this->load->view('templates/lecturer_runningtest_navbar', $adata);
			// 	$this->load->view('examinations/view_runningtest_lecturer', $data);
			// 	$this->load->view('templates/user_navbars_footer');
		}
	}

	public function searchResult1()
	{
		$all = "";
		$name = $this->input->post('users_name');
		$this->load->model('Examination_model', 'examination_model');
		$data['all_mark'] = $this->examination_model->searchUserMarks($name);
		$data['all_marks'] = $this->examination_model->allUserMarks();
		$userName = $this->examination_model->userName();

		foreach ($userName as $users) {
			$all .= $users['user_username'];
		}

		if ($this->input->post('submit_form')) {
			if (strpos($all, $name) !== false) {
				$this->load->view('examinations/view_all_report', $data);
			} else {
				$data['message'] = 'No Data Found';
				$this->load->view('examinations/view_all_report', $data);
			}
		} else {
			// redirect('http://localhost/MidAtp/admin/viewResult', 'refresh');
			//     $this->load->view('templates/lecturer_runningtest_navbar', $adata);
			// 	$this->load->view('examinations/view_runningtest_lecturer', $data);
			// 	$this->load->view('templates/user_navbars_footer');
		}
	}
}
